﻿$inp = Read-host "Enter file name with extention"

$drivers = Get-PSDrive -PSProvider FileSystem
($drivers).Root

foreach ($d in ($drivers).Root) {
    (Get-ChildItem -Path $d -Recurse | Where-Object {$_.Name -eq $inp}).Fullname
}


# another way
$driver = @("c:\")
$drivers = (Get-PSDrive -PSProvider FileSystem).Root
$file = "aaa.txt"

foreach($d in $drivers){
    $retr = Get-ChildItem -Path -Filter $file -Recurse -Force -ErrorAction SilentlyContinue
    if($retr){
        Write-Host "$($file) location is: " -NoNewline
        Write-Host $retr.FullName -ForegroundColor Cyan
    }
    else{
        Write-Host "no such file is present $d" -ForegroundColor Red
    }
}