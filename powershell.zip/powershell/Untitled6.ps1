﻿
$web = read-Host 
$out = Test-Connection $web



cls
if(Test-Connection (Read-Host "Enter website name") -Count 2 -ea SilentlyContinue){
    write-host "pinging" -ForegroundColor Green
    }
else{
    write-host "not pinging" -ForegroundColor Red
}

