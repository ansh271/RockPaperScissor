﻿#fetching the data from xml file with xml format
[xml]$xmldata = Get-Content ./books.xml

cls

#checking its type
$xmldata.GetType()

#processing the data
$xmldata.catalog.book | Where-Object {$_.id -match "112"} | `
Select-Object id,author,description


#to see full text without .....
$xmldata.catalog.book | Where-Object {$_.id -match "112"} | `
Select-Object id, author, description | Format-Table -AutoSize -Wrap
