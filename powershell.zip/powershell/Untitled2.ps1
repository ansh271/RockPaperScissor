﻿$h2 = @{
    key3 = "Value3"
    key4 = "value4"
}

$h1 = @{key1="value1";
        key2 = "value2";
    }
cls
#adding elements
$h1.Add("key5","value5")
$h1

#modifying elements
$h1["key1"] = "changed value"
$h1

#deleting element
$h1.Remove("key2")
$h1

cls
Get-Service | Select-Object Name, `
DisplayName, `
@{l= "report"; e={$_.status}} `
-First 3


