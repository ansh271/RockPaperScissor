﻿<#
operators
    logical --> -and, -or, -nor
    arthematic --> +,-,/,*,%
    comparison --> -eq, -ne, -gt,
                   -lt, -ge, -le
#>

<#
condition statement
    -if
    -nested if
    -if-else
    -nested if-else
    -switch statement
no ternary operator
#>
$no = 15
$result = @{
    $true = "no is greater than 15";
    $false  = "no is less than 15"
}[$no -gt 18]
Write-Output $result


cls
$number = 1
$result = @{
    $true = "The number is greater than 10"; 
    $false = "The number is 10 or less"}[$number -gt 10]
Write-Output $result


switch(1)