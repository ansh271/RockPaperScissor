﻿cls
cd alias:\

Get-PSDrive -PSProvider Registry 

Get-ChildItem HKCU:\ 

#creating a folder in HKCU which is in registory
New-Item -Path HKCU:\ -Name "Test" -Force

#create file in HKCU:\test
New-ItemProperty -Path HKCU:\Test -Name "child" -Value "this is child" -Force

#change the registory key-value
Set-ItemProperty -Path HKCU:\Test -Name "child" -Value "this is not end" -Force

#removing child file
Remove-ItemProperty -Path HKCU:\Test -Name "child" -Force

#removing test directory
Remove-Item -Path HKCU:\Test -Force