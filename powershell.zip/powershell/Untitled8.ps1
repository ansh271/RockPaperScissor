﻿#normal function
function sum2{
  [int]$a = Read-Host "Enter the value of a: " 
  [int]$b = Read-Host "Enter the value of b: "
  #$a = $a+$b
  
    Write-Host $($a + $b)
}

sum2


function sum1{
  [int]$a = Read-Host "Enter the value of a: " 
  [int]$b = Read-Host "Enter the value of b: "
  $c = $a+$b
  
    Write-Host $c
}

sum1




# parameters in function

#prints int value
function add3{
    param(
        [int]$n1,$n2
    )
    Write-Host $($n1+$n2)
}

cls
$nn1 = Read-Host "Enter the value of nn1"
$nn2 = Read-Host "Enter the value of nn2"
add3 -n1 $nn1 -n2 $nn2 


# will concatinate
function add4{
    param(
        $n1,$n2
    )
    Write-Host $($n1+$n2)
}

cls
$nn1 = Read-Host "Enter the value of nn1"
$nn2 = Read-Host "Enter the value of nn2"
add4 -n1 $nn1 -n2 $nn2



#Advance function


#will show result in integer if we add {int + string(int)}
#moreover we can apply parameter to all the variables also
function add4{
[cmdletbinding()]
    param(
        [int][parameter(Mandatory = $true,HelpMessage="Enter integer Value")]$n1,
        $n2
    )
    Write-Host $($n1+$n2)
}

cls
$nn1 = Read-Host "Enter the int value of nn1"
$nn2 = Read-Host "Enter the int value of nn2"
add4 -n2 $nn2

#validation in advance function

function hii{
    [CmdletBinding()]
    param(
        [parameter(Mandatory = $true)]
        [ValidateSet("ansh","vishal","shraddha")]$a
    )
    Write-Host "Hello $a"
}

hii