﻿Get-Service -Name s* ` |
Select-Object Name,Status,StartType ` |
ConvertTo-Html | Out-File sNameServices.html


Get-Process | Select-Object ProcessName, ID | ConvertTo-Html | `
Out-File filename.html





Get-Process | Select-Object ProcessName, ID | Export-Clixml filename.xml



