﻿$arr1 = @(
    @(1,2,3),
    @(4,5,6),
    @(7,8,9)
)
foreach ($num in $arr1) {
    Write-Host "The number is $num"
}



$arr2 = @(
    @(1,2,3),
    @(4,5,6),
    @(7,8,9)
)
foreach ($num in $arr2) {
    foreach($n in $num){
        Write-Host "The number is $n"
    }
}


