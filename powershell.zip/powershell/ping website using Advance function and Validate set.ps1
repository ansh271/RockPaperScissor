﻿function test-ping{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet("www.google.com","Flipkart.com","youtube.com")]$web
    )
    Test-Connection $web -Count 1
}

$websites = @("www.google.com","Flipkart.com","youtube.com")
foreach($w in $websites){
    Test-ping $w
}