﻿# while loop
$arr = @(1,2,3,4,5,15)
$c = 0
cls
while(10 -gt $arr[$c]){
    Write-Host $arr[$c]
    $c += 1
}


# for-each loop
$numbers = @(1, 2, 3, 4, 5)
foreach ($num in $numbers) {
    Write-Host "The number is $num"
}


# do while loop
$a = 0
do{
    $ch = @(1,2,3)
    Write-Host $ch[$a]
    $a++
}while($a -le $ch.Length)


# for loop
for($i=0;$i -lt 10 ;$i++){
    write-host $i
}