﻿Get-Process | Sort-Object -Property CPU -Descending




Get-Process | Sort-Object -Property CPU -Descending `
| Select-Object "CPU" -First 10 -Unique