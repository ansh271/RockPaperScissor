﻿cls
$ser = Read-Host "Enter the service name"
$status = (Get-Service $ser).Status
write-host "Service status: "$status

if($status -eq "Running"){
$ch = Read-Host "Do you want to stop the service ?y/n"
    if($ch -eq "y"){
        Stop-Service -Name $ser -Force
    }
}
else{
$ch = Read-Host "Do you want to Start the service ?y/n"
    if($ch -eq "y"){
        Start-Service -Name $ser
    }
}

Write-Host "Service status: "(Get-Service $ser).Status