﻿notepad.exe $profile


#finding ip address by 3 ways
Get-NetIPAddress | Where-Object {$_.PrefixOrigin -eq "Dhcp"} | Select-Object Ipaddress

(Get-NetIPAddress | Where-Object {$_.PrefixOrigin -eq "Dhcp"}).IPAddress

$a = Get-NetIPAddress | select-Object IPAddress
write-host ($a[-2]).IPAddress


# finding MAC address
(Get-NetAdapter | Where-Object {$_.name -eq "wi-fi"}).MacAddress

#
(Get-NetAdapter | Where-Object {$_.name -eq "wi-fi" -and $_.Status -eq "up"}).MacAddress

