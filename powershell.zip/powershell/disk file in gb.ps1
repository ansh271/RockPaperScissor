﻿
Get-WmiObject -Class Win32_logicaldisk | `
Select-Object deviceID, `
@{ label = "FreeSpace in GB" ; exp = {[math]::Round(($_.FreeSpace/1GB),2)}}, `
@{label = "Size in GB" ; exp = {[math]::Round(($_.Size/1GB),2)}}