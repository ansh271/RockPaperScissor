﻿cls 
$obj1 = New-Object -TypeName psobject 
$obj1.GetType()
$obj1 | Get-Member

#adding a member 
Add-Member -InputObject $obj1 -MemberType NoteProperty -Name "LTIMtr" -Value "Batch35.2"


#adding multiple members to object
$newobj = @{
    pro1 = "value1"
    pro2 = "value2"
    pro3 = "value3"
    pro4 = "value4"
}

$obj2 = New-Object -TypeName psobject -Property $newobj

$obj2 | Get-Member