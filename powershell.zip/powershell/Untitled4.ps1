﻿#conditions
cls
$ans = Read-Host "Enter the service name to check status"
$val = Get-Service -Name $ans
write-host "$($val.Name) is $($val.Status)" -ForegroundColor DarkYellow


cls
$sta = Get-Service | Select-Object name, status

$sta.Name[0]

for($i=0 ;$i -lt $sta.Count ;$i++){
    if("running" -eq $sta.Status[$i]){
        write-host "$($sta.Name[$i])" -ForegroundColor Green
    }
    else{
        write-host "$($sta.Name[$i])" -ForegroundColor DarkRed
    }
}



cls
$sta = Get-Service | Where-Object {$_.status -eq "running"} | Select-Object name
for($i=0 ;$i -lt $sta.Count ;$i++){
    Write-Host $sta[$i] -ForegroundColor Green
}