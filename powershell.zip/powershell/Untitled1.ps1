﻿
$a = @(1,2,3)
$b = @("A","B","C")

$c = @($a,
    $b,
    @(4,5,6),
    @("D","E","F")
    @(Get-Process)
)


for($i=0;$i -lt 5; $i++){
    Write-Output $c[$i]
}

$h2 = @{
    key3 = "Value3"
    key4 = "value4"
}

$h1 = @{key1="value1";
        key2 = "value2";
    }
$h1


$h1.count

