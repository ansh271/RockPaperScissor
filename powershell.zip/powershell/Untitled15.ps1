﻿$folderpath
$time

Get-ChildItem -Path $folderpath -Recurse | Where-Object {
    $_.LastWriteTime.TimeOfDay -gt ([datetime]::ParseExact($time, "h:mm tt", $null)).TimeOfDay
}