﻿
for(;;){
        $ch = Read-Host "enter value for switch"
        switch($ch){
            1{write-host "switch 1"}
            2{write-host "switch 2"}
            3{write-host "switch 3"}
            4{write-host "switch 4"}
            5{ break }
            default{write-host "default"}
        }
        if($ch -ge 5){
            break
        }
    }





    do{
     $ch = Read-Host "enter value for switch"
        switch($ch){
            1{write-host "switch 1"}
            2{write-host "switch 2"}
            3{write-host "switch 3"}
            4{write-host "switch 4"}
            5{ break }
            default{write-host "default"}
        }
    }while($ch -lt 5);