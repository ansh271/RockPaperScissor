﻿Write-Host "Total no of processes are : "(Get-Process | measure).Count


Get-VMBios -VMName server1


Get-WmiObject -Class Win32_BIOS | Format-Table

HOSTNAME.EXE

cls
Get-WmiObject -Class Win32_DiskDrive