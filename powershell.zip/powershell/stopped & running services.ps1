﻿Get-Service | Where-Object {$_.Status -eq "Running"} | ForEach-Object {
    Write-Host $_.DisplayName -ForegroundColor Green
    $_.DisplayName | Out-File Running.txt -Append
}


Get-Service | Where-Object {$_.Status -eq "Stopped"} | ForEach-Object {
    Write-Host $_.DisplayName -ForegroundColor Red
    $_.DisplayName | Out-File Stopped.txt -Append
}
